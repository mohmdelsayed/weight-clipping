import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 14})
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False
# use latex for font rendering
plt.rcParams['text.usetex'] = True


def avg_return_curve(x, y, stride, total_steps):
    """
    Author: Rupam Mahmood (armahmood@ualberta.ca)
    :param x: A list of list of termination steps for each episode. len(x) == total number of runs
    :param y: A list of list of episodic return. len(y) == total number of runs
    :param stride: The timestep interval between two aggregate datapoints to be calculated
    :param total_steps: The total number of time steps to be considered
    :return: time steps for calculated data points, average returns for each data points, std-errs
    """
    assert len(x) == len(y)
    num_runs = len(x)

    avg_ret = np.zeros(total_steps // stride)
    stderr_ret = np.zeros(total_steps // stride)
    avg_ret2 = np.zeros(total_steps // stride)
    stderr_ret2 = np.zeros(total_steps // stride)
    steps = np.arange(stride, total_steps + stride, stride)
    num_rets = np.zeros(total_steps // stride)
    individ_avg_rets_per_run = []
    for i in range(0, total_steps // stride):
        rets = []
        avg_rets_per_run = []
        for run in range(num_runs):
            xa = np.array(x[run])
            ya = np.array(y[run])
            rets.append(
                ya[np.logical_and(i * stride < xa, xa <= (i + 1) * stride)].tolist()
            )
            avg_rets_per_run.append(np.mean(rets[-1]))
        individ_avg_rets_per_run.append(avg_rets_per_run)
        flat_rets = np.array([ret for l in rets for ret in l])
        num_rets[i] = flat_rets.shape[0]
        avg_ret[i] = flat_rets.mean()
        stderr_ret[i] = flat_rets.std() / np.sqrt(num_rets[i])
        avg_ret2[i] = np.mean(avg_rets_per_run)
        stderr_ret2[i] = np.std(avg_rets_per_run) / np.sqrt(num_runs)

    return (
        steps,
        avg_ret,
        stderr_ret,
        num_rets,
        avg_ret2,
        stderr_ret2,
        individ_avg_rets_per_run,
    )

env = "Ant"
what_to_plot = "approx_kl"
colors = ['tab:red', 'tab:blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']
plt.figure(figsize=(8, 6))
for color, run_dir in zip(colors, [f"Adam-Policy-Collapse/{env}/{what_to_plot}", f"Clipped-Policy-Collapse/{env}/{what_to_plot}"]): # Ant
    event_list = os.listdir(run_dir)
    x, y = [], []
    for event_file in event_list:
        event_file_path = os.path.join(run_dir, event_file)
        df = pd.read_csv(event_file_path)
        steps = list(df["Step"])
        returns = list(df["Value"])
        x.append(steps)
        y.append(returns)

    # steps, avg_ret, stderr_ret, num_rets, avg_ret2, stderr_ret2, _ = avg_return_curve(x, y, 200_000, 5_000_000)
    steps, avg_ret, stderr_ret, num_rets, avg_ret2, stderr_ret2, _ = avg_return_curve(x, y, 500_000, 30_000_000)
    plt.plot(steps, avg_ret, label=run_dir, linewidth=2.5, color=color)
    plt.fill_between(steps, avg_ret - stderr_ret, avg_ret + stderr_ret, alpha=0.2, color=color)
    plt.xlabel("Time Step", fontsize=32)
    # fontsize of x and y ticks
    plt.xticks(fontsize=20)
    plt.yticks(fontsize=20)
    if what_to_plot=="episodic_returns":
        plt.ylabel(f"Average Episodic Return", fontsize=32)
    elif what_to_plot=="approx_kl":
        plt.ylabel(f"Average Approximate KL", fontsize=32)
    elif what_to_plot=="grad_l1":
        plt.ylabel(r"$\ell_1$ Norm of Gradients", fontsize=32)
    elif what_to_plot=="grad_l2":
        plt.ylabel(r"$\ell_2$ Norm of Gradients", fontsize=32)
    elif what_to_plot=="weight_l1":
        plt.ylabel(r"$\ell_1$ Norm of Weights", fontsize=32)
    elif what_to_plot=="weight_l2":
        plt.ylabel(r"$\ell_2$ Norm of Weights", fontsize=32)
    elif what_to_plot=="n_saturated_95":
        plt.ylabel(r"\% Saturated Units ($\geq$0.95)", fontsize=32)
    elif what_to_plot=="n_saturated_90":
        plt.ylabel(r"\% Saturated Units ($\geq$0.90)", fontsize=32)
    else:
        raise ValueError(f"Unknown plot type: {what_to_plot}")
    # plt.legend()
    plt.title(f"{env}-4", fontsize=32, y=1.0, pad=-16)
plt.savefig(f"{env}_{what_to_plot}-v4+title.pdf", bbox_inches="tight")